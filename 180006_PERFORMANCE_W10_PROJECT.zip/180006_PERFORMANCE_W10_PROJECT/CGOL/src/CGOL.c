/*
 ============================================================================
 Name        : CGOL.c
 Author      : Harshmeen Kaur Lamba
 Version     :
 Copyright   : Your copyright notice
 Description : Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include<stdio.h>

int sizeOfRow, sizeOfCol, as, aliveRow, aliveCol, generations;
void NextGeneration(int a[sizeOfRow][sizeOfCol], int sizeOfRow, int sizeOfCol);

int main()
    {

	printf("Enter the size of row\n");
	scanf("%d", &sizeOfRow);
	printf("Enter the size of column\n");
	scanf("%d", &sizeOfCol);

   int a[sizeOfRow][sizeOfCol];

   for(int p = 0; p<sizeOfRow; p++){
	   for(int q = 0; q<sizeOfCol; q++){
		   a[p][q] = 0;                    
	   }
   }

   printf("Enter the number of cells that you want to keep alive\n");
   scanf("%d", &as);        

   for(int o = 0; o<as; o++){               
	   printf("Enter the position of the alive cell in row\n");
	   scanf("%d", &aliveRow);
	   printf("Enter the position of the alive cell in column\n");
	   scanf("%d", &sizeOfCol);
	   a[aliveRow][aliveCol] = 1;    

   }
    
        printf("Initial State\n");    
        for (int i = 0; i < sizeOfRow; i++)
        {
            for (int j = 0; j < sizeOfCol; j++)
            {
                if (a[i][j] == 0)
                    printf("0");        
                else
                    printf("1");    
            }
           printf("\n");
        }
       printf("\n");
        NextGeneration(a, sizeOfRow, sizeOfCol);
    }


    void NextGeneration(int a[sizeOfRow][sizeOfCol], int sizeOfRow, int sizeOfCol)
                                                                                     
    {

        int no = 1;
    	int b[sizeOfRow][sizeOfCol];

    printf("Enter the number of generations\n");
    scanf("%d", &generations);                        
    printf("\n");

    for(int g = 0; g<generations; g++){        
        for (int l = 1; l < sizeOfRow ; l++)
        {
            for (int m = 1; m < sizeOfCol ; m++)
            {

            	 int numOfAliveNeighbours = 0;           


            if(l == 0){                     
            	for (int i = 0; i <= 1; i++)           
            	   for (int j = -1; j <= 1; j++)        
            	     numOfAliveNeighbours += a[l + i][m + j];   

           	         numOfAliveNeighbours -= a[l][m];       
            }


            else if(l == 0 && m == 0){  
            	for (int i = 0; i <= 1; i++)            
            	   for (int j = 0; j <= 1; j++)        
            	     numOfAliveNeighbours += a[l + i][m + j];   

            	     numOfAliveNeighbours -= a[l][m];       

            }


            else if(m == 0){                
            	for (int i = -1; i <= 1; i++)            
            	   for (int j = 0; j <= 1; j++)        
            	     numOfAliveNeighbours += a[l + i][m + j];   

            	     numOfAliveNeighbours -= a[l][m];       

            }


            else if(m == 0 && l == sizeOfRow - 1){
            	for (int i = -1; i < 1; i++)            
            	   for (int j = 0; j <= 1; j++)        
            	     numOfAliveNeighbours += a[l + i][m + j];   

            	     numOfAliveNeighbours -= a[l][m];      

            }

            else if(l == sizeOfRow - 1){
            	for (int i = -1; i < 1; i++)            
            	   for (int j = -1; j <= 1; j++)        
            	     numOfAliveNeighbours += a[l + i][m + j];   

            	     numOfAliveNeighbours -= a[l][m];       

            }

            else if(l == sizeOfRow -1 && m == sizeOfCol -1){
            	for (int i = -1; i < 1; i++)           
            	   for (int j = -1; j < 1; j++)        
            	     numOfAliveNeighbours += a[l + i][m + j];  

            	     numOfAliveNeighbours -= a[l][m];       

            }

            else if(m == sizeOfCol -1 ){
            	for (int i = -1; i <= 1; i++)            
            	   for (int j = -1; j < 1; j++)        
            	     numOfAliveNeighbours += a[l + i][m + j];   

            	     numOfAliveNeighbours -= a[l][m];      

            }

            else if(l == 0 && m == sizeOfCol - 1){
            	for (int i = 0; i <= 1; i++)            
            	   for (int j = -1; j < 1; j++)        
            	     numOfAliveNeighbours += a[l + i][m + j];   

            	     numOfAliveNeighbours -= a[l][m];      

            }

            else {
            	for (int i = -1; i <= 1; i++)            
            	   for (int j = -1; j <= 1; j++)        
            	     numOfAliveNeighbours += a[l + i][m + j];   

            	     numOfAliveNeighbours -= a[l][m];       

            }

    

            
                if ((a[l][m] == 1) && (numOfAliveNeighbours < 2))
                    b[l][m] = 0;

                
                else if ((a[l][m] == 1) && (numOfAliveNeighbours > 3))
                    b[l][m] = 0;

                
                else if ((a[l][m] == 0) && (numOfAliveNeighbours == 3))
                    b[l][m] = 1;

                
                else
                    b[l][m] = a[l][m];
            }
        }


        printf("%d Generation:\n", no);          
            no++;
        for (int i = 0; i < sizeOfRow; i++)
        {
            for (int j = 0; j < sizeOfCol; j++)
            {
                if (a[i][j] == 0)
                   printf("0");        
                else
                    printf("1");       
            }
            printf("\n");
        }
        printf("\n");
    }
    }


